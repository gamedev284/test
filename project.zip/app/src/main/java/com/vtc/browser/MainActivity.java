package com.vtc.browser;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Message;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

import androidx.webkit.ScriptHandler;
import androidx.webkit.WebViewCompat;
import androidx.webkit.WebViewFeature;


public class MainActivity extends Activity {

    // Site picker shown on launch (app/src/main/assets/home.html). Edit that file to add sites.
    private static final String HOME_URL = "file:///android_asset/home.html";

    private static final int FILE_REQUEST = 1001;

    private FrameLayout root;
    // Holds all web content. Sized to the chosen aspect ratio and centered; the rest of the screen stays black.
    private FrameLayout stage;
    private String aspectSetting = "";
    private float aspect = 0f; // width / height, or 0 for full screen
    private int stageW = 0, stageH = 0;
    private WebView webView;
    private WebView popupView;
    private View customView;
    private WebChromeClient.CustomViewCallback customViewCallback;
    private ValueCallback<Uri[]> fileCallback;
    private ScriptStore scripts;
    // True when the WebView can run scripts before the page loads (like Tampermonkey's document-start).
    private boolean documentStart;
    private final java.util.List<ScriptHandler> scriptHandlers = new java.util.ArrayList<>();
    private long lastBackPress = 0;

    private final WebChromeClient chromeClient = new WebChromeClient() {
        @Override
        public void onPermissionRequest(final PermissionRequest request) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    request.grant(request.getResources());
                }
            });
        }

        // Login popups (window.open). Opened as an overlay WebView so window.opener keeps working.
        @Override
        public boolean onCreateWindow(WebView view, boolean isDialog, boolean isUserGesture, Message resultMsg) {
            closePopup();
            popupView = createWebView();
            popupView.setWebViewClient(new WebViewClient() {
                @Override
                public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest request) {
                    return handleUrl(request.getUrl());
                }
            });
            stage.addView(popupView, matchParent());
            WebView.WebViewTransport transport = (WebView.WebViewTransport) resultMsg.obj;
            transport.setWebView(popupView);
            resultMsg.sendToTarget();
            return true;
        }

        @Override
        public void onCloseWindow(WebView window) {
            if (window == popupView) {
                root.post(new Runnable() {
                    @Override
                    public void run() {
                        closePopup();
                    }
                });
            }
        }

        // Element fullscreen (requestFullscreen) from the page.
        @Override
        public void onShowCustomView(View view, CustomViewCallback callback) {
            if (customView != null) {
                callback.onCustomViewHidden();
                return;
            }
            customView = view;
            customViewCallback = callback;
            stage.addView(view, matchParent());
            hideSystemUi();
        }

        @Override
        public void onHideCustomView() {
            if (customView == null) return;
            stage.removeView(customView);
            customView = null;
            if (customViewCallback != null) customViewCallback.onCustomViewHidden();
            customViewCallback = null;
            hideSystemUi();
        }

        // File picker, used by the script's settings import.
        @Override
        public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
            if (fileCallback != null) fileCallback.onReceiveValue(null);
            fileCallback = callback;
            try {
                startActivityForResult(params.createIntent(), FILE_REQUEST);
            } catch (Exception e) {
                fileCallback = null;
                return false;
            }
            return true;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Window window = getWindow();
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if (Build.VERSION.SDK_INT >= 28) {
            WindowManager.LayoutParams lp = window.getAttributes();
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            window.setAttributes(lp);
        }

        WebView.setWebContentsDebuggingEnabled(true);
        scripts = new ScriptStore(this);

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        setContentView(root);
        stage = new FrameLayout(this);
        stage.setBackgroundColor(Color.BLACK);
        root.addView(stage, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.CENTER));
        root.addOnLayoutChangeListener(new View.OnLayoutChangeListener() {
            @Override
            public void onLayoutChange(View v, int l, int t, int r, int b, int ol, int ot, int or, int ob) {
                root.post(new Runnable() {
                    @Override
                    public void run() {
                        applyStageSize();
                    }
                });
            }
        });
        aspectSetting = getSharedPreferences("settings", MODE_PRIVATE).getString("aspect", "full");
        aspect = parseAspect(aspectSetting);

        webView = createWebView();
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest request) {
                return handleUrl(request.getUrl());
            }

            @Override
            public void onPageFinished(WebView v, String url) {
                injectScript(v);
            }
        });
        stage.addView(webView, matchParent());

        documentStart = WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT);
        registerScripts();

        webView.loadUrl(HOME_URL);
        hideSystemUi();
    }

    private WebView createWebView() {
        WebView v = new WebView(this);
        v.setBackgroundColor(Color.BLACK);

        WebSettings s = v.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setSupportMultipleWindows(true);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);

        // Look like regular Chrome instead of an embedded WebView, which some sites block.
        String ua = s.getUserAgentString()
                .replace("; wv)", ")")
                .replaceAll("Version/\\d+(\\.\\d+)* ", "");
        s.setUserAgentString(ua);

        CookieManager cookies = CookieManager.getInstance();
        cookies.setAcceptCookie(true);
        cookies.setAcceptThirdPartyCookies(v, true);

        v.setWebChromeClient(chromeClient);
        return v;
    }

    private boolean handleUrl(Uri uri) {
        String scheme = uri.getScheme();
        if (scheme == null) return false;
        if (scheme.equals("cloudplay")) {
            startActivity(new Intent(this, ScriptsActivity.class));
            return true;
        }
        if (scheme.equals("http") || scheme.equals("https") || scheme.equals("about") || scheme.equals("file")
                || scheme.equals("data") || scheme.equals("blob") || scheme.equals("javascript")) {
            return false;
        }
        try {
            Intent intent = scheme.equals("intent")
                    ? Intent.parseUri(uri.toString(), Intent.URI_INTENT_SCHEME)
                    : new Intent(Intent.ACTION_VIEW, uri);
            startActivity(intent);
        } catch (Exception ignored) {
        }
        return true;
    }

    /** Registers enabled scripts to run as each page starts loading. Takes effect on the next page load. */
    private void registerScripts() {
        if (!documentStart) return;
        for (ScriptHandler h : scriptHandlers) h.remove();
        scriptHandlers.clear();
        java.util.Set<String> allOrigins = java.util.Collections.singleton("*");
        String spoof = screenSpoofScript();
        if (spoof != null) {
            // Registered first so sites read the boxed size before any of their own code runs.
            scriptHandlers.add(WebViewCompat.addDocumentStartJavaScript(webView, spoof, allOrigins));
        }
        for (ScriptStore.Script s : scripts.enabled()) {
            scriptHandlers.add(WebViewCompat.addDocumentStartJavaScript(webView, ScriptStore.wrap(s, true), allOrigins));
        }
    }

    /** Fallback for older WebView versions: run scripts after the page has loaded. */
    private void injectScript(WebView v) {
        if (documentStart) return;
        String spoof = screenSpoofScript();
        if (spoof != null) v.evaluateJavascript(spoof, null);
        String url = v.getUrl();
        if (url == null || !(url.startsWith("http://") || url.startsWith("https://"))) return;
        for (ScriptStore.Script s : scripts.forUrl(url)) {
            v.evaluateJavascript(ScriptStore.wrap(s), null);
        }
    }

    private void closePopup() {
        if (popupView == null) return;
        WebView p = popupView;
        popupView = null;
        stage.removeView(p);
        p.destroy();
    }

    /** "16:9" -> 1.777..., anything else (e.g. "full") -> 0. */
    static float parseAspect(String value) {
        try {
            String[] parts = value.split(":");
            if (parts.length != 2) return 0f;
            float w = Float.parseFloat(parts[0].trim()), h = Float.parseFloat(parts[1].trim());
            return (w > 0 && h > 0) ? w / h : 0f;
        } catch (Exception e) {
            return 0f;
        }
    }

    /** Fits the stage to the aspect ratio inside the screen, re-registering the screen spoof if the size changed. */
    private void applyStageSize() {
        int w = root.getWidth(), h = root.getHeight();
        if (w <= 0 || h <= 0) return;
        if (aspect > 0) {
            if ((float) w / h > aspect) w = Math.round(h * aspect);
            else h = Math.round(w / aspect);
        }
        FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) stage.getLayoutParams();
        int lw = aspect > 0 ? w : ViewGroup.LayoutParams.MATCH_PARENT;
        int lh = aspect > 0 ? h : ViewGroup.LayoutParams.MATCH_PARENT;
        if (lp.width != lw || lp.height != lh) {
            lp.width = lw;
            lp.height = lh;
            lp.gravity = Gravity.CENTER;
            stage.setLayoutParams(lp);
        }
        if (w != stageW || h != stageH) {
            stageW = w;
            stageH = h;
            registerScripts();
        }
    }

    /**
     * Makes the page see the boxed area as the whole screen: screen size, available size,
     * outer window size and device-* media queries all report the stage size.
     */
    private String screenSpoofScript() {
        if (aspect <= 0 || stageW <= 0 || stageH <= 0) return null;
        return "(function(){var W=" + stageW + ",H=" + stageH + ";"
                + "function r(){return window.devicePixelRatio||1;}"
                + "function w(){return Math.round(W/r());}function h(){return Math.round(H/r());}"
                + "function d(o,k,f){try{Object.defineProperty(o,k,{get:f,configurable:true});}catch(e){}}"
                + "var S=window.Screen&&Screen.prototype;"
                + "if(S){d(S,'width',w);d(S,'height',h);d(S,'availWidth',w);d(S,'availHeight',h);"
                + "d(S,'availLeft',function(){return 0;});d(S,'availTop',function(){return 0;});}"
                + "d(window,'outerWidth',w);d(window,'outerHeight',h);"
                + "d(window,'screenX',function(){return 0;});d(window,'screenY',function(){return 0;});"
                + "d(window,'screenLeft',function(){return 0;});d(window,'screenTop',function(){return 0;});"
                + "var mm=window.matchMedia;if(mm){window.matchMedia=function(q){"
                + "return mm.call(window,String(q).replace(/device-aspect-ratio/g,'aspect-ratio')"
                + ".replace(/device-width/g,'width').replace(/device-height/g,'height'));};}"
                + "})();";
    }

    private static FrameLayout.LayoutParams matchParent() {
        return new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
    }

    @SuppressWarnings("deprecation")
    private void hideSystemUi() {
        if (Build.VERSION.SDK_INT >= 30) {
            getWindow().setDecorFitsSystemWindows(false);
            WindowInsetsController c = getWindow().getInsetsController();
            if (c != null) {
                c.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                c.setSystemBarsBehavior(WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_FULLSCREEN);
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemUi();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == FILE_REQUEST) {
            if (fileCallback != null) {
                fileCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data));
                fileCallback = null;
            }
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @SuppressWarnings("deprecation")
    @Override
    public void onBackPressed() {
        if (customView != null) {
            chromeClient.onHideCustomView();
            return;
        }
        if (popupView != null) {
            if (popupView.canGoBack()) popupView.goBack();
            else closePopup();
            return;
        }
        if (webView.canGoBack()) {
            webView.goBack();
            return;
        }
        // No history left but not on the site picker: go back to it.
        String url = webView.getUrl();
        if (url != null && !url.startsWith(HOME_URL)) {
            webView.loadUrl(HOME_URL);
            return;
        }
        // Require two back presses to exit, so a stray back gesture doesn't close the game.
        long now = System.currentTimeMillis();
        if (now - lastBackPress < 2000) {
            super.onBackPressed();
        } else {
            lastBackPress = now;
            Toast.makeText(this, "Press back again to exit", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView == null) return;
        String setting = getSharedPreferences("settings", MODE_PRIVATE).getString("aspect", "full");
        if (!setting.equals(aspectSetting)) {
            aspectSetting = setting;
            aspect = parseAspect(setting);
            stageW = stageH = 0; // force re-register with the new size
            applyStageSize();
            // Reload so the current page measures the new size from the start.
            if (webView.getUrl() != null && webView.getUrl().startsWith("http")) webView.reload();
        }
        registerScripts();
        hideSystemUi();
    }

    @Override
    protected void onPause() {
        super.onPause();
        CookieManager.getInstance().flush();
    }

    @Override
    protected void onDestroy() {
        closePopup();
        if (webView != null) webView.destroy();
        super.onDestroy();
    }
}
