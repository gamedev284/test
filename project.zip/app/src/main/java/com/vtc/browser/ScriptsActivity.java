package com.vtc.browser;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONObject;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/** Script manager screen. Its page is local and can't navigate anywhere, so only it can use the bridge. */
public class ScriptsActivity extends Activity {

    private static final int PICK_FILE = 2001;

    private WebView web;
    private ScriptStore store;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        store = new ScriptStore(this);

        web = new WebView(this);
        web.setBackgroundColor(Color.BLACK);
        web.getSettings().setJavaScriptEnabled(true);
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest request) {
                return true; // stay on the local manager page
            }
        });
        web.addJavascriptInterface(new Bridge(), "CP");
        setContentView(web);
        web.loadUrl("file:///android_asset/scripts.html");
    }

    private void showMessage(final String msg) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                web.evaluateJavascript("refresh();showMsg(" + JSONObject.quote(msg) + ")", null);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode != PICK_FILE) {
            super.onActivityResult(requestCode, resultCode, data);
            return;
        }
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        try (InputStream in = getContentResolver().openInputStream(uri)) {
            String err = store.add(ScriptStore.readAll(in));
            showMessage(err == null ? "Script added." : err);
        } catch (Exception e) {
            showMessage("Could not read the file: " + e.getMessage());
        }
    }

    @Override
    protected void onDestroy() {
        if (web != null) web.destroy();
        super.onDestroy();
    }

    private class Bridge {
        @JavascriptInterface
        public String list() {
            return store.listJson();
        }

        @JavascriptInterface
        public void setEnabled(String id, boolean on) {
            store.setEnabled(id, on);
        }

        @JavascriptInterface
        public void remove(String id) {
            store.remove(id);
        }

        @JavascriptInterface
        public String addCode(String code) {
            String err = store.add(code);
            return err == null ? "" : err;
        }

        @JavascriptInterface
        public void pickFile() {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                    i.setType("*/*");
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    try {
                        startActivityForResult(Intent.createChooser(i, "Choose a script file"), PICK_FILE);
                    } catch (Exception e) {
                        showMessage("No file picker available.");
                    }
                }
            });
        }

        @JavascriptInterface
        public void addFromUrl(final String address) {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        if (!address.startsWith("https://") && !address.startsWith("http://")) {
                            throw new Exception("Address must start with https://");
                        }
                        HttpURLConnection c = (HttpURLConnection) new URL(address).openConnection();
                        c.setConnectTimeout(15000);
                        c.setReadTimeout(30000);
                        c.setInstanceFollowRedirects(true);
                        int status = c.getResponseCode();
                        if (status != 200) throw new Exception("Server replied " + status);
                        String code;
                        try (InputStream in = c.getInputStream()) {
                            code = ScriptStore.readAll(in);
                        }
                        String err = store.add(code);
                        showMessage(err == null ? "Script added." : err);
                    } catch (Exception e) {
                        showMessage("Download failed: " + e.getMessage());
                    }
                }
            }).start();
        }
    }
}
