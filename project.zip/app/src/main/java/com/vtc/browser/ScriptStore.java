package com.vtc.browser;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Stores user scripts, their on/off state, and decides which ones run on a page. */
public class ScriptStore {

    public static final String BUILTIN_ID = "builtin-touch";
    private static final String BUILTIN_ASSET = "touch_controller.js";
    private static final Pattern META_LINE = Pattern.compile("^\\s*//\\s*@(\\S+)\\s+(.*?)\\s*$");
    private static final Pattern SAFE_ID = Pattern.compile("^[A-Za-z0-9_-]+$");

    public static class Script {
        public String id;
        public String name;
        public String code;
        public boolean builtin;
        public String runAt = "document-idle";
        public boolean noframes;
        public final List<String> includes = new ArrayList<>();
        public final List<String> excludes = new ArrayList<>();
    }

    private final Context ctx;
    private final File dir;
    private final SharedPreferences prefs;

    public ScriptStore(Context ctx) {
        this.ctx = ctx;
        this.dir = new File(ctx.getFilesDir(), "scripts");
        if (!dir.exists()) dir.mkdirs();
        this.prefs = ctx.getSharedPreferences("scripts", Context.MODE_PRIVATE);
    }

    public List<Script> all() {
        List<Script> list = new ArrayList<>();

        Script b = new Script();
        b.id = BUILTIN_ID;
        b.builtin = true;
        b.code = readAsset(BUILTIN_ASSET);
        parseMeta(b);
        b.name = "Touch Controller (built-in)";
        list.add(b);

        File[] files = dir.listFiles();
        if (files != null) {
            Arrays.sort(files);
            for (File f : files) {
                String fn = f.getName();
                if (!fn.endsWith(".js")) continue;
                Script s = new Script();
                s.id = fn.substring(0, fn.length() - 3);
                s.code = readFile(f);
                if (s.code == null) continue;
                parseMeta(s);
                if (s.name == null) s.name = s.id;
                list.add(s);
            }
        }
        return list;
    }

    /** All enabled scripts (URL rules are checked inside each wrapped script). */
    public List<Script> enabled() {
        List<Script> out = new ArrayList<>();
        for (Script s : all()) {
            if (s.code != null && isEnabled(s.id)) out.add(s);
        }
        return out;
    }

    /** Enabled scripts whose @match / @include rules fit this page. */
    public List<Script> forUrl(String url) {
        List<Script> out = new ArrayList<>();
        for (Script s : all()) {
            if (s.code != null && isEnabled(s.id) && matches(s, url)) out.add(s);
        }
        return out;
    }

    public boolean isEnabled(String id) {
        return prefs.getBoolean("on_" + id, true);
    }

    public void setEnabled(String id, boolean on) {
        prefs.edit().putBoolean("on_" + id, on).apply();
    }

    /** Saves a new script. Returns an error message, or null on success. */
    public String add(String code) {
        if (code == null || code.trim().isEmpty()) return "The script is empty.";
        String id = "s" + System.currentTimeMillis();
        try (OutputStream out = new FileOutputStream(new File(dir, id + ".js"))) {
            out.write(code.getBytes("UTF-8"));
        } catch (Exception e) {
            return "Could not save the script: " + e.getMessage();
        }
        return null;
    }

    public void remove(String id) {
        if (id == null || BUILTIN_ID.equals(id) || !SAFE_ID.matcher(id).matches()) return;
        new File(dir, id + ".js").delete();
        prefs.edit().remove("on_" + id).apply();
    }

    public String listJson() {
        JSONArray arr = new JSONArray();
        try {
            for (Script s : all()) {
                JSONObject o = new JSONObject();
                o.put("id", s.id);
                o.put("name", s.name);
                o.put("builtin", s.builtin);
                o.put("enabled", isEnabled(s.id));
                o.put("runsOn", s.includes.isEmpty() ? "All sites" : join(s.includes));
                arr.put(o);
            }
        } catch (Exception ignored) {
        }
        return arr.toString();
    }

    /** Wraps a script with a run-once guard and basic Greasemonkey/Tampermonkey functions. */
    public static String wrap(Script s) {
        return wrap(s, false);
    }

    /**
     * @param atDocumentStart true when injected before the page loads, so @run-at is honored;
     *                        false when injected into an already loaded page.
     */
    public static String wrap(Script s, boolean atDocumentStart) {
        String id = JSONObject.quote(s.id);
        String name = JSONObject.quote(s.name == null ? s.id : s.name);
        return "(function(){"
                + "if(!/^https?:/.test(location.href))return;"
                + "if(window.top!==window&&" + (s.builtin || s.noframes) + ")return;"
                + "var __h=location.href;if(!(" + jsUrlTest(s) + "))return;"
                + "var __cp=window.__cpScripts=window.__cpScripts||{};if(__cp[" + id + "])return;__cp[" + id + "]=1;"
                + "var unsafeWindow=window;"
                + "var GM_info={script:{name:" + name + ",version:''},scriptHandler:'Cloud Play'};"
                + "var __k='cp_gm_'+" + id + "+'_';"
                + "function GM_addStyle(c){var e=document.createElement('style');e.textContent=c;(document.head||document.documentElement).appendChild(e);return e;}"
                + "function GM_getValue(k,d){try{var v=localStorage.getItem(__k+k);return v===null?d:JSON.parse(v);}catch(e){return d;}}"
                + "function GM_setValue(k,v){try{localStorage.setItem(__k+k,JSON.stringify(v));}catch(e){}}"
                + "function GM_deleteValue(k){try{localStorage.removeItem(__k+k);}catch(e){}}"
                + "function GM_listValues(){var r=[];try{for(var i=0;i<localStorage.length;i++){var k=localStorage.key(i);if(k.indexOf(__k)===0)r.push(k.slice(__k.length));}}catch(e){}return r;}"
                + "function GM_log(){console.log.apply(console,arguments);}"
                + "function GM_openInTab(u){return window.open(u);}"
                + "function GM_setClipboard(t){try{navigator.clipboard.writeText(String(t));}catch(e){}}"
                + "function GM_registerMenuCommand(){return 0;}"
                + "function GM_unregisterMenuCommand(){}"
                + "function GM_xmlhttpRequest(d){var c=new AbortController();"
                + "fetch(d.url,{method:d.method||'GET',headers:d.headers,body:d.data,signal:c.signal,credentials:'include'})"
                + ".then(function(r){return r.text().then(function(t){var o={status:r.status,statusText:r.statusText,responseText:t,response:t,finalUrl:r.url,responseHeaders:''};"
                + "if(d.responseType==='json'){try{o.response=JSON.parse(t);}catch(e){}}"
                + "if(d.onload)d.onload(o);if(d.onloadend)d.onloadend(o);});})"
                + ".catch(function(e){if(d.onerror)d.onerror(e);if(d.onloadend)d.onloadend(e);});"
                + "return{abort:function(){c.abort();}};}"
                + "var GM={info:GM_info,addStyle:GM_addStyle,xmlHttpRequest:GM_xmlhttpRequest,openInTab:GM_openInTab,setClipboard:GM_setClipboard,"
                + "getValue:function(k,d){return Promise.resolve(GM_getValue(k,d));},"
                + "setValue:function(k,v){GM_setValue(k,v);return Promise.resolve();},"
                + "deleteValue:function(k){GM_deleteValue(k);return Promise.resolve();},"
                + "listValues:function(){return Promise.resolve(GM_listValues());}};"
                + "function __run(){try{\n" + s.code + "\n}catch(e){console.error('[Cloud Play] Script error in '+" + name + ",e);}}"
                + (atDocumentStart && !"document-start".equals(s.runAt) && !"document-body".equals(s.runAt)
                    ? "if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',__run,{once:true});else __run();"
                    : "__run();")
                + "})();";
    }

    // ---- helpers ----

    private static void parseMeta(Script s) {
        if (s.code == null) return;
        int start = s.code.indexOf("==UserScript==");
        int end = s.code.indexOf("==/UserScript==");
        if (start < 0 || end < start) return;
        for (String line : s.code.substring(start, end).split("\n")) {
            if (line.trim().matches("//\\s*@noframes\\s*")) s.noframes = true;
            Matcher m = META_LINE.matcher(line);
            if (!m.find()) continue;
            String key = m.group(1);
            String val = m.group(2);
            if (key.equals("name") && s.name == null) s.name = val;
            else if (key.equals("match") || key.equals("include")) s.includes.add(val);
            else if (key.equals("exclude") || key.equals("exclude-match")) s.excludes.add(val);
            else if (key.equals("run-at")) s.runAt = val;
        }
    }

    /** JavaScript expression testing variable __h (the page URL) against the script's rules. */
    private static String jsUrlTest(Script s) {
        String inc = s.includes.isEmpty() ? "true" : jsAny(s.includes);
        String exc = s.excludes.isEmpty() ? "false" : jsAny(s.excludes);
        return "(" + inc + ")&&!(" + exc + ")";
    }

    private static String jsAny(List<String> patterns) {
        StringBuilder sb = new StringBuilder();
        for (String p : patterns) {
            if (sb.length() > 0) sb.append("||");
            String t = p.trim();
            if (t.equals("<all_urls>") || t.equals("*")) {
                sb.append("true");
            } else if (t.length() > 2 && t.startsWith("/") && t.endsWith("/")) {
                sb.append("(function(){try{return new RegExp(").append(JSONObject.quote(t.substring(1, t.length() - 1)))
                        .append(").test(__h);}catch(e){return false;}})()");
            } else {
                sb.append("new RegExp(").append(JSONObject.quote(globToRegex(t))).append(").test(__h)");
            }
        }
        return sb.toString();
    }

    private static String globToRegex(String p) {
        String q = p.replace("://*.", "://\u0001");
        StringBuilder re = new StringBuilder("^");
        for (int i = 0; i < q.length(); i++) {
            char c = q.charAt(i);
            if (c == '*') re.append(".*");
            else if (c == '\u0001') re.append("(?:[^/]*\\.)?");
            else {
                if ("\\.[]{}()+-?^$|/".indexOf(c) >= 0) re.append('\\');
                re.append(c);
            }
        }
        return re.append("$").toString();
    }

    private static boolean matches(Script s, String url) {
        for (String p : s.excludes) if (patternMatches(p, url)) return false;
        if (s.includes.isEmpty()) return true;
        for (String p : s.includes) if (patternMatches(p, url)) return true;
        return false;
    }

    static boolean patternMatches(String p, String url) {
        try {
            p = p.trim();
            if (p.equals("<all_urls>") || p.equals("*")) return true;
            if (p.length() > 2 && p.startsWith("/") && p.endsWith("/")) {
                return Pattern.compile(p.substring(1, p.length() - 1)).matcher(url).find();
            }
            return Pattern.compile(globToRegex(p)).matcher(url).matches();
        } catch (Exception e) {
            return false;
        }
    }

    private static String join(List<String> list) {
        StringBuilder sb = new StringBuilder();
        for (String s : list) {
            if (sb.length() > 0) sb.append(", ");
            sb.append(s);
        }
        return sb.toString();
    }

    private String readAsset(String name) {
        try (InputStream in = ctx.getAssets().open(name)) {
            return readAll(in);
        } catch (Exception e) {
            return null;
        }
    }

    private static String readFile(File f) {
        try (InputStream in = new java.io.FileInputStream(f)) {
            return readAll(in);
        } catch (Exception e) {
            return null;
        }
    }

    public static String readAll(InputStream in) throws java.io.IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
        return out.toString("UTF-8");
    }
}
